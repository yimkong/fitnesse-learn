/*
 * Copyright (c) 2006 Rick Mugridge, www.RimuResearch.com
 * Released under the terms of the GNU General Public License version 2 or later.
*/
package fitlibrary.parser.tree;

/**
 *
 */
public interface TreeInterface {
    public Tree toTree();
//    public static boolean equals(Object o1, Object o2);
//    public static Tree parseTree(String s);
}

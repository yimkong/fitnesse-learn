package fit;

public interface FixtureSupplier {
	Fixture getFixture();
}

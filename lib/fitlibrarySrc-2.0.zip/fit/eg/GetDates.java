package fit.eg;

import fit.ColumnFixture;

public class GetDates extends ColumnFixture {
  public String inDate;

  public String updatedDate() {
    return inDate;
  }
}
